#include <stdlib.h> // Required for malloc and NULL
#include <string.h> // Required for strcpy, strcmp, and other string functions

typedef struct requisicao {
    char nome[41];
    int inscricao;
    char procedimento[11];

} Requisicao;

/* data */
Requisicao* cria_requisicao(char* nome, int inscricao, char* procedimento) {
        Requisicao* requisicao = (Requisicao*)malloc(sizeof(Requisicao)); // Aloca memória para a requisição
        if (requisicao == NULL) { // Verifica se a alocação foi bem-sucedida
            return NULL; // Retorna NULL em caso de falha
        }
        strcpy(requisicao->nome, nome); // Copia o nome da requisição
        requisicao->inscricao = inscricao; // Atribui o número de inscrição
        strcpy(requisicao->procedimento, procedimento); // Copia o procedimento da requisição
        return requisicao; // Retorna o ponteiro da requisição criada
    }

    //Retorna o nome  armazenado na requisicao
    const char* get_nome(Requisicao* requisicao) {
        return requisicao->nome; // Retorna o nome da requisição
    }
    //Retorna o numero de inscricao armazenado na requisicao
    int get_inscricao(Requisicao* requisicao) {
        return requisicao->inscricao; // Retorna o número de inscrição da requisição
    }
    //Retorna o procedimento armazenado na requisicao
    const char* get_procedimento(Requisicao* requisicao) {
        return requisicao->procedimento; // Retorna o procedimento da requisição
    }
    //Libera a memoria alocada para a requisicao
    void libera(Requisicao* requisicao) {
        free(requisicao); // Libera a memória da requisição
    }
    // Define the Estrutura type with a tamanho field
    typedef struct estrutura {
        int tamanho;
    } Estrutura;
    
    
    
