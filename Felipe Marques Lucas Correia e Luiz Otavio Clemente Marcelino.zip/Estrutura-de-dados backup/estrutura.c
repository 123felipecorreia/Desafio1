#include "estrutura.h"
#include <stdlib.h>
#include <stdio.h>
#include "requisicao.h"


// Definir a estrutura de um nó da lista encadeada
typedef struct fila {
    Requisicao* req; // Ponteiro para a estrutura Requisicao
    struct fila* proximo; //ponteiro para a fila
} Fila;

// Definir a estrutura da fila
typedef struct Estrutura {
    Fila* inicio; // Ponteiro para o início da fila
    Fila* fim; // Ponteiro para o fim da fila
    int tamanho; // Tamanho da fila
} Estrutura;

// Função para criar uma nova fila e retorno do ponteiro

struct Estrutura *create() {
    struct Estrutura *estrutura = malloc(sizeof(struct Estrutura)); // Aloca memória para a estrutura
    if (estrutura) { // Verifica se a alocação foi bem-sucedida
        estrutura->inicio = NULL; // Inicializa o início da fila como NULL
        estrutura->tamanho = 0; // Inicializa o tamanho da fila como 0
        estrutura->fim = NULL; // Inicializa o fim da fila como NULL
        estrutura->tamanho = 0; // Inicializa o tamanho da fila como 0
    }
    return estrutura; // Retorna o ponteiro para a nova fila
}
// Função para inserir um novo nó na fila
int inserir (Estrutura* estrutura, Requisicao* requisicao) {
    Fila* novo = (Fila*)malloc(sizeof(Fila)); // Aloca memória para o novo nó
    if (novo == NULL) { // Verifica se a alocação foi bem-sucedida
        return 1; // Retorna em caso de falha
    }
    novo->req = requisicao; // Atribui o ponteiro da requisição ao novo nó
    novo->proximo = NULL; // Inicializa o próximo nó como NULL

    if (estrutura->fim != NULL) { // Se a fila não estiver vazia
        estrutura->fim->proximo = novo; // O próximo do último nó aponta para o novo nó
    } else { // Se a fila estiver vazia
        estrutura->inicio = novo; // O início da fila aponta para o novo nó
    }
    estrutura->fim = novo; // O fim da fila agora é o novo nó
    estrutura->tamanho++; // Incrementa o tamanho da fila

    return 0; // Retorna 0 em caso de sucesso
}
// Função para remover um nó da fila

Requisicao* remover(Estrutura* estrutura) {
    if (estrutura->inicio == NULL) { // Se a fila estiver vazia
        return NULL; // Retorna NULL
    }
    Fila* temp = estrutura->inicio; // Armazena o nó a ser removido
    Requisicao* requisicao = temp->req; // Armazena a requisição do nó a ser removido
    estrutura->inicio = estrutura->inicio->proximo; // O início da fila agora é o próximo nó

    if (estrutura->inicio == NULL) { // Se a fila ficou vazia após a remoção
        estrutura->fim = NULL; // O fim da fila também deve ser NULL
    }
    free(temp); // Libera a memória do nó removido
    estrutura->tamanho--; // Decrementa o tamanho da fila
    return requisicao; // Retorna a requisição removida
}

// Função para obter o tamanho da fila
int get_size(Estrutura* estrutura) {
    return estrutura->tamanho; // Retorna o tamanho da fila
}
// Função para liberar a memória da fila
void libera_estrutura(Estrutura* estrutura) {
    while (estrutura->inicio != NULL) { // Enquanto a fila não estiver vazia
        Fila* temp = estrutura->inicio; // Armazena o nó a ser removido
        estrutura->inicio = estrutura->inicio->proximo; // O início da fila agora é o próximo nó
        libera(temp->req); // Libera a memória da requisição
        free(temp); // Libera a memória do nó
    }
    free(estrutura); // Libera a memória da estrutura da fila
}



    


  


    

