#ifndef ESTRUTURA_H
#define ESTRUTURA_H

#include "requisicao.h"

typedef struct Estrutura Estrutura;
	

Estrutura *create();
int inserir(Estrutura *estrutura, Requisicao *requisicao);
int get_size(Estrutura *estrutura);
Requisicao *remover(Estrutura *estrutura);
void libera_estrutura(Estrutura *estrutura); 

#endif // ESTRUTURA_H
